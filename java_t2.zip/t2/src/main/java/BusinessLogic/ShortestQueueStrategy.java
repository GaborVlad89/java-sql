package BusinessLogic;
import Model.Server;
import Model.Task;
import java.util.List;
public class ShortestQueueStrategy implements Strategy{
    @Override
    public void addTask(List<Server> servers, Task t)
    {
        int index = -1;
        int minQueueSize = Integer.MAX_VALUE;
        for (int i = 0; i < servers.size(); i++) {
            Server server = servers.get(i);
            if (server.taskListNotFull()) {
                int queueSize = server.getQueueSize();
                if (queueSize < minQueueSize) {
                    minQueueSize = queueSize;
                    index = i;
                }
            }
        }

        if (index != -1) {
            servers.get(index).addTask(t);
        }
    }
}