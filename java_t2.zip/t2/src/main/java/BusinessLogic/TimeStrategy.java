package BusinessLogic;
import Model.Server;
import Model.Task;
import java.util.List;
public class TimeStrategy implements Strategy {
    @Override
    public void addTask(List<Server> servers, Task task) {
        int minWaitingPeriod = Integer.MAX_VALUE;
        Server selectedServer = null;
        for (Server server : servers)
        {
            if (server.taskListNotFull())
            {
                int waitingPeriod = server.getWaitingPeriod();
                if (waitingPeriod < minWaitingPeriod)
                {
                    minWaitingPeriod = waitingPeriod;
                    selectedServer = server;
                }
            }
        }
        if (selectedServer != null) {
            selectedServer.addTask(task);
        }
    }
}
