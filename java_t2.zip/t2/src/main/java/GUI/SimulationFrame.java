package GUI;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
public class SimulationFrame implements ActionListener {
    JTextField text1;
    JTextField text2;
    JTextField text3;
    JTextField text4;
    JTextField text5;
    JTextField text6;
    JTextField text7;
    JLabel label1;
    JLabel label2;
    JLabel label3;
    JLabel label4;
    JLabel label5;
    JLabel label6;
    JLabel label7;
    JButton buton1;
    JButton buton2;
    JTextArea textArea;
    ArrayList<Integer> list;
    Boolean ready=false;
    JFrame frame;
    public SimulationFrame (){
        list=new ArrayList<>();
        frame=new JFrame("APP");
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setSize(600,400);

        label1=new JLabel("number_of_clients");
        label1.setBounds(65,90,150,17);
        text1=new JTextField("4");//clients
        text1.setBounds(170, 85, 35, 25);
        frame.add(text1);
        frame.add(label1);

        label2=new JLabel("threads");
        label2.setBounds(65,125,50,17);
        text3=new JTextField("2");//threads
        text3.setBounds(170, 120, 35, 25);

        label3=new JLabel("simulation");
        label3.setBounds(65,160,135,17);
        text5=new JTextField("60");//time limit
        text5.setBounds(170, 155, 35, 25);

        label4=new JLabel("min_arrival_time");
        label4.setBounds(65,195,105,17);
        text2=new JTextField("2");//min arrival
        text2.setBounds(170, 190, 35, 25);

        label5=new JLabel("max_arrival_time");
        label5.setBounds(65,230,105,17);
        text4=new JTextField("30");//max arrival
        text4.setBounds(170, 225, 35, 25);

        label6=new JLabel("min_service_time");
        label6.setBounds(65,265,105,17);
        text6=new JTextField("2");//min service
        text6.setBounds(170, 260, 35, 25);

        label7=new JLabel("max_service_time");
        label7.setBounds(65,300,105,17);
        text7=new JTextField("4");//max service
        text7.setBounds(170, 295, 35, 25);

        buton1=new JButton("start");
        buton1.setBounds(300,150,135,25);

        buton2=new JButton("stop");
        buton2.setBounds(300,200,135,25);

        frame.add(text2);
        frame.add(text3);
        frame.add(text4);
        frame.add(text5);
        frame.add(text6);
        frame.add(text7);
        frame.add(label2);
        frame.add(label3);
        frame.add(label4);
        frame.add(label5);
        frame.add(label6);
        frame.add(label7);
        frame.add(buton1);
        frame.add(buton2);
        buton1.addActionListener(this);
        frame.setLayout(null);
        frame.setVisible(true);
        frame.getContentPane().setBackground(Color.orange);
    }
    @Override
    public void actionPerformed(ActionEvent event){
        Integer noOfClients=Integer.parseInt(text1.getText());
        Integer noOfThreads=Integer.parseInt(text3.getText());
        Integer timeLimit=Integer.parseInt(text5.getText());
        Integer minArrivalTime=Integer.parseInt(text2.getText());
        Integer maxArrivalTime=Integer.parseInt(text4.getText());
        Integer minServiceTime=Integer.parseInt(text6.getText());
        Integer maxServiceTime=Integer.parseInt(text7.getText());
        list.add(noOfClients);
        list.add(noOfThreads);
        list.add(timeLimit);
        list.add(minArrivalTime);
        list.add(maxArrivalTime);
        list.add(minServiceTime);
        list.add(maxServiceTime);
        ready=true;
    }
    public List<Integer> getInitValues (){
        while (!ready)
        {
            buton1.setName("Start");
        }
        return list;
    }
}