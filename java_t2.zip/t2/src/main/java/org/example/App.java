package org.example;
import BusinessLogic.SimulationManager;
import GUI.SimulationFrame;
/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        //System.out.println( "Hello World!" );
        SimulationManager gen= new SimulationManager();
        Thread t=new Thread(gen);
        t.start();
    }
}
