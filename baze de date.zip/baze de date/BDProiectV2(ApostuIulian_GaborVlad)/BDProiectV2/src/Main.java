import LogIn.LogInPage;

public class Main {
    public static void main(String[] args) {
        LogInPage login = new LogInPage();
    }
}