package Business_Logic.validators;
public interface Validator <T> {
    public void validate(T t);
}