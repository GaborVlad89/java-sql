package Business_Logic.validators;
import Model.Product;
public class Count implements Validator<Product>{
    private static final int MIN_COUNT = 1;
    private static final int MAX_COUNT = 50;
    public void validate(Product t) {
        if (t.getProduct_count() < 1 || t.getProduct_count() > 50) {
            throw new IllegalArgumentException("The Count must be between 1 and 50!");
        }
    }
}
