package Business_Logic.validators;
import Model.Product;
public class Price implements Validator<Product>{
    private static final int MIN_PRICE = 1;
    public Price() {
    }
    public void validate(Product t) {
        if (t.getProduct_price() < 1) {
            throw new IllegalArgumentException("pretul nu poate fi 0 sau maic mic decat 0!");
        }
    }
}
