package Business_Logic;
import Business_Logic.validators.Count;
import Business_Logic.validators.Price;
import Business_Logic.validators.Validator;
import Data_Access.ProductDAO;
import Model.Product;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
public class ProductBLL {
    private List<Validator<Product>> validators = new ArrayList();
    public ProductBLL() {
        this.validators.add(new Count());
        this.validators.add(new Price());
    }
    public int insertProduct(Product product) {
        Iterator var2 = this.validators.iterator();

        while(var2.hasNext()) {
            Validator<Product> v = (Validator)var2.next();
            v.validate(product);
        }
        return ProductDAO.insert(product);
    }
}
