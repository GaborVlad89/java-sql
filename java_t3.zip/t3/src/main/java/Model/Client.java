package Model;
public class Client {
    private int id_client;
    private String client_name;
    private int client_age;
    /**
     * Constructs a Client object with specified id, name, and age.
     * @param id_client the id of the client
     * @param client_name the name of the client
     * @param client_age the age of the client
     */
    public Client(int id_client, String client_name, int client_age) {
        super();
        this.id_client = id_client;
        this.client_name = client_name;
        this.client_age = client_age;
    }
    /**
     * Constructs a Client object with specified name and age.
     * @param client_name the name of the client
     * @param client_age the age of the client
     */
    public Client(String client_name, int client_age) {
        super();
        this.client_name = client_name;
        this.client_age = client_age;
    }
    /**
     * @return the name of the client
     */
    public String getClient_name() {
        return this.client_name;
    }
    /**
     * @return the age of the client
     */
    public int getClient_age() {
        return this.client_age;
    }
}

