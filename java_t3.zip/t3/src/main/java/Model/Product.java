/**
 *A class representing a product
 */
package Model;
public class Product {
    private int id_product;
    private String product_name;
    private int product_count;
    private int product_price;
    /**
     * Constructs a new product with a specified ID, name, count, and price
     * @param id_product    the ID of the product
     * @param product_name  the name of the product
     * @param product_count the count of the product
     * @param product_price the price of the product
     */
    public Product(int id_product, String product_name, int product_count, int product_price) {
        super();
        this.id_product = id_product;
        this.product_name = product_name;
        this.product_count = product_count;
        this.product_price = product_price;
    }
    /**
     * Constructs a new product with a specified name, count, and price
     * @param product_name  the name of the product
     * @param product_count the count of the product
     * @param product_price the price of the product
     */
    public Product(String product_name, int product_count, int product_price) {
        super();
        this.product_name = product_name;
        this.product_count = product_count;
        this.product_price = product_price;
    }
    /**
     * @return the name of the product
     */
    public String getProduct_name() {
        return product_name;
    }
    /**
     * @returnthe count of the product
     */
    public int getProduct_count() {return product_count;}
    /**
     * @return the price of the product
     */
    public int getProduct_price() {
        return product_price;
    }
}
