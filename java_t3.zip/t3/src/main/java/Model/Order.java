/**
 Class representing an order made by a client for a product.
 */
package Model;
public class Order {
    private int id_order;
    private String order_client;
    private String order_product;
    private int order_count;
    private int order_price;
    /**
     * Constructs an Order object with given id, client name, product name and quantity.
     * @param id_order      The id of the order.
     * @param order_client  The client who made the order.
     * @param order_product The product ordered by the client.
     * @param order_count   The quantity of the product ordered.
     * @param order_price   The price of the product ordered.
     */
    public Order(int id_order, String order_client, String order_product) {
        super();
        this.id_order = id_order;
        this.order_client = order_client;
        this.order_product= order_product;
        this.order_count = order_count;
        this.order_price= order_price;
    }
    /**
     * Constructs an Order object with given client name, product name and quantity.
     * @param order_client  The client who made the order.
     * @param order_product The product ordered by the client.
     * @param order_count   The quantity of the product ordered.
     */
    public Order(String order_client, String order_product, int order_count){
        super();
        this.order_client = order_client;
        this.order_product = order_product;
        this.order_count = order_count;
    }
    /**
     * @return The client who made the order.
     */
    public String getOrder_client() {
        return order_client;
    }
    /**
     * @return The product ordered by the client.
     */
    public String getOrder_product() {
        return order_product;
    }
    /**
     * @return The quantity of the product ordered.
     */
    public int getOrder_count() {
        return order_count;
    }
}
