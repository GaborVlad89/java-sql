package org.example;
import Presentation.Main_view;
public class main {
    public static void main(String[] args)  {
        ////
        new Main_view();
    }
}