/**
 The ConnectionFactory class provides the necessary methods for creating a connection to a MySQL database and managing its resources.
 */
package ConnectionFactory;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
public class ConnectionFactory {
    private static final Logger LOGGER = Logger.getLogger(ConnectionFactory.class.getName());
    private static final String DRIVER = "com.mysql.cj.jdbc.Driver";
    private static final String DBURL = "jdbc:mysql://localhost:3306/schooldb?sslMode=DISABLED";
    private static final String USER = "root";
    private static final String PASS = "vlad";
    private static ConnectionFactory singleInstance = new ConnectionFactory();
    /**
     * Constructor for the ConnectionFactory class that initializes the MySQL JDBC driver.
     */
    public ConnectionFactory(){
        try{
            Class.forName(DRIVER);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
    /**
     * Creates a connection to a MySQL database using the specified connection URL, username, and password.
     * @return a connection to the database
     */
    private Connection createConnection() {
        Connection connection = null;
        try {
            connection = DriverManager.getConnection(DBURL, USER, PASS);
        } catch (SQLException e) {
            LOGGER.log(Level.WARNING, "An error occured while trying to connect to the database");
            e.printStackTrace();
        }
        return connection;
    }
    /**
     * Returns a connection to the database.
     * @return a connection to the database
     */
    public static Connection getConnection() {
        return singleInstance.createConnection();
    }
    /**
     * Closes a database connection.
     * @param connection the connection to be closed
     */
    public static void close(Connection connection) {
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException e) {
                LOGGER.log(Level.WARNING, "An error occured while trying to close the connection");
            }
        }
    }
    /**
     * Closes a statement.
     * @param statement the statement to be closed
     */
    public static void close(Statement statement) {
        if (statement != null) {
            try {
                statement.close();
            } catch (SQLException e) {
                LOGGER.log(Level.WARNING, "An error occured while trying to close the statement");
            }
        }
    }
    /**
     * Closes a result set.
     * @param resultSet the result set to be closed
     */
    public static void close(ResultSet resultSet) {
        if (resultSet != null) {
            try {
                resultSet.close();
            } catch (SQLException e) {
                LOGGER.log(Level.WARNING, "An error occured while trying to close the ResultSet");
            }
        }
    }

}
