/**
 *Represents the main window of the application.
 */
package Presentation;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
public class Main_view extends JFrame {
    public Main_view() {

        setTitle("Main Window");
        setSize(800, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JMenuBar menuBar = new JMenuBar();
        setJMenuBar(menuBar);

        JMenu optionsMenu = new JMenu("Options");
        menuBar.add(optionsMenu);

        ImageIcon clientIcon = new ImageIcon("client.png");
        JMenuItem clientItem = new JMenuItem("Client", clientIcon);
        optionsMenu.add(clientItem);
        clientItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e){
                new Client_view();
            }
        });

        ImageIcon orderIcon = new ImageIcon("order.png");
        JMenuItem orderItem = new JMenuItem("Order", orderIcon);
        optionsMenu.add(orderItem);
        orderItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e){
                new Order_view();
            }
        });

        ImageIcon productIcon = new ImageIcon("product.png");
        JMenuItem productItem = new JMenuItem("Product", productIcon);
        optionsMenu.add(productItem);
        productItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e){
                new Product_view();
            }
        });
        setVisible(true);
    }
}
