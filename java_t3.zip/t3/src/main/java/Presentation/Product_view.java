/**
 The Product_Window class creates the GUI for the Product Operations window
 that enables the user to add, edit, delete and view products.
 */
package Presentation;
import Business_Logic.ProductBLL;
import Data_Access.AbstractDAO;
import Data_Access.ProductDAO;
import Model.Product;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Product_view extends JFrame {
    /**
     * The Product_Window constructor creates the main window and adds buttons to
     * add, edit, delete and view products.
     */
    public Product_view() {
        setTitle("Product");
        setSize(896, 504);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(null);
        JMenuBar menuBar = new JMenuBar();
        setJMenuBar(menuBar);
        JMenu optionsMenu = new JMenu("Product Operations");
        menuBar.add(optionsMenu);

        ImageIcon addIcon = new ImageIcon("Add new product.png");
        JMenuItem addItem = new JMenuItem("Add new product", addIcon);
        optionsMenu.add(addItem);
        addItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e){
                Product_view.this.addNewProduct();
            }
        });
        ImageIcon editIcon = new ImageIcon("Edit product.png");
        JMenuItem editItem = new JMenuItem("Edit product", editIcon);
        optionsMenu.add(editItem);
        editItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e){
                Product_view.this.editNewProduct();
            }
        });

        ImageIcon delIcon = new ImageIcon("Delete product.png");
        JMenuItem delItem = new JMenuItem("Delete product", delIcon);
        optionsMenu.add(delItem);
        delItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e){
                Product_view.this.deleteNewProduct();
            }
        });

        ImageIcon vieIcon = new ImageIcon("View product.png");
        JMenuItem vieItem = new JMenuItem("View product", vieIcon);
        optionsMenu.add(vieItem);
        vieItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e){
                Product_view.this.viewNewProduct();
            }
        });
        setVisible(true);
    }

    /**
     * The addNewProduct method creates a new window for adding a product and
     * adds the necessary labels, text fields, and buttons.
     */
    public void addNewProduct() {
        JFrame addNewProduct = new JFrame("Add Product");
        addNewProduct.setSize(500, 400);
        addNewProduct.setLocationRelativeTo(this);
        addNewProduct.setLayout(null);

        JLabel productNameLabel = new JLabel("Product name: ");
        productNameLabel.setBounds(80, 80, 100, 20);
        addNewProduct.add(productNameLabel);

        JTextField productNameField = new JTextField();
        productNameField.setBounds(180, 80, 100, 20);
        addNewProduct.add(productNameField);

        JLabel productPriceLabel = new JLabel("Product price: ");
        productPriceLabel.setBounds(80, 100, 100, 20);
        addNewProduct.add(productPriceLabel);

        JTextField productPriceField = new JTextField();
        productPriceField.setBounds(180, 100, 100, 20);
        addNewProduct.add(productPriceField);

        JLabel productCountLabel = new JLabel("Product count: ");
        productCountLabel.setBounds(80, 120, 100, 20);
        addNewProduct.add(productCountLabel);

        JTextField productCountField = new JTextField();
        productCountField.setBounds(180, 120, 100, 20);
        addNewProduct.add(productCountField);

        JButton addButton = new JButton("Add");
        addButton.setBounds(180, 150, 100, 20);
        addButton.addActionListener(e -> {
            Product product = new Product(productNameField.getText(), Integer.parseInt(productCountField.getText()), Integer.parseInt(productPriceField.getText()));
            ProductBLL productBLL = new ProductBLL();
            productBLL.insertProduct(product);
            addNewProduct.dispose();
        });
        addNewProduct.add(addButton);
        addNewProduct.setVisible(true);
    }

    /**
     * Opens a JFrame for editing a product. Allows the user to edit the name, price, and count of a product by inputting new values into corresponding JTextFields.
     * When the "Edit" button is pressed, the changes are applied to the database using the ProductDAO.updateByID method.
     */
    public void editNewProduct() {
        JFrame editNewProduct = new JFrame("Edit Product");
        editNewProduct.setSize(500, 400);
        editNewProduct.setLocationRelativeTo(this);
        editNewProduct.setLayout(null);

        JLabel productIdLabel = new JLabel("Product ID: ");
        productIdLabel.setBounds(80, 80, 100, 20);
        editNewProduct.add(productIdLabel);

        JTextField productIdField = new JTextField();
        productIdField.setBounds(180, 80, 100, 20);
        editNewProduct.add(productIdField);

        JLabel productNameLabel = new JLabel("Product name: ");
        productNameLabel.setBounds(80, 100, 100, 20);
        editNewProduct.add(productNameLabel);

        JTextField productNameField = new JTextField();
        productNameField.setBounds(180, 100, 100, 20);
        editNewProduct.add(productNameField);

        JLabel productPriceLabel = new JLabel("Product price: ");
        productPriceLabel.setBounds(80, 120, 100, 20);
        editNewProduct.add(productPriceLabel);

        JTextField productPriceField = new JTextField();
        productPriceField.setBounds(180, 120, 100, 20);
        editNewProduct.add(productPriceField);

        JLabel productCountLabel = new JLabel("Product count: ");
        productCountLabel.setBounds(80, 140, 100, 20);
        editNewProduct.add(productCountLabel);

        JTextField productCountField = new JTextField();
        productCountField.setBounds(180, 140, 100, 20);
        editNewProduct.add(productCountField);

        JButton editButton = new JButton("Edit");
        editButton.setBounds(180, 170, 100, 20);
        editButton.addActionListener(e -> {
            ProductDAO.updateByID(productNameField.getText(), Integer.parseInt(productCountField.getText()), Integer.parseInt(productPriceField.getText()), Integer.parseInt(productIdField.getText()));
            editNewProduct.dispose();
        });
        editNewProduct.add(editButton);

        editNewProduct.setVisible(true);
    }

    /**
     * Opens a new frame to delete a product by its ID.
     * The frame contains a text field to input the product ID, a label to indicate the field's purpose, and a button to delete the product.
     * When the button is clicked, the product with the specified ID is deleted from the database.
     */
    public void deleteNewProduct() {
        JFrame deleteNewProduct = new JFrame("Delete Product");
        deleteNewProduct.setSize(500, 400);
        deleteNewProduct.setLocationRelativeTo(this);
        deleteNewProduct.setLayout(null);

        JLabel productIdLabel = new JLabel("Product ID: ");
        productIdLabel.setBounds(80, 80, 100, 20);
        deleteNewProduct.add(productIdLabel);

        JTextField productIdField = new JTextField();
        productIdField.setBounds(180, 80, 100, 20);
        deleteNewProduct.add(productIdField);

        JButton deleteButton = new JButton("Delete");
        deleteButton.setBounds(180, 110, 100, 20);
        deleteButton.addActionListener(e -> {
            ProductDAO.deleteById(Integer.parseInt(productIdField.getText()));
            deleteNewProduct.dispose();
        });
        deleteNewProduct.add(deleteButton);

        deleteNewProduct.setVisible(true);
    }

    /**
     * Displays a window containing a view of all the products in the ProductDAO.
     * The products are retrieved from the database and stored in an Object array, which is then passed to the
     * {@link AbstractDAO#viewAllObjects(Object[], JFrame, int)} method to display them in the window.
     * The window is created using a JFrame object and displayed on the screen.
     */
    public void viewNewProduct() {
        JFrame viewNewProduct = new JFrame("View Products");
        viewNewProduct.setSize(500, 400);
        viewNewProduct.setLocationRelativeTo(this);
        viewNewProduct.setLayout(null);

        int numberOfProducts = ProductDAO.getNrOfProducts();
        Object[] products = new Object[numberOfProducts + 1];
        int j = 1;
        for (int i = 1; i <= numberOfProducts; i++) {
            while (ProductDAO.findById(j) == null) j++;
            if (ProductDAO.findById(j) != null) products[i] = ProductDAO.findById(j);
            j++;
        }
        AbstractDAO.viewAllObjects(products, viewNewProduct, numberOfProducts);
        viewNewProduct.setVisible(true);
    }
}
