/**
 * The Client_Window class represents a graphical user interface window for the client operations.
 * It extends JFrame.
 */
package Presentation;
import Data_Access.AbstractDAO;
import Data_Access.ClientDAO;
import Data_Access.ProductDAO;
import Model.Client;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
/**
 * Constructor for the Client_Window class.
 * Initializes and sets up the client operations window with all its components.
 */
public class Client_view extends JFrame {
    private int order_number = 0;
    public Client_view() {
        JMenuBar menuBar = new JMenuBar();
        setJMenuBar(menuBar);
        JMenu optionsMenu = new JMenu("Client Operations");
        menuBar.add(optionsMenu);

        ImageIcon clientIcon = new ImageIcon("Add New Client.png");
        JMenuItem clientItem = new JMenuItem("Add New Client", clientIcon);
        optionsMenu.add(clientItem);
        clientItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e){
                Client_view.this.addNewClient();
            }
        });
        ImageIcon editIcon = new ImageIcon("Edit Client.png");
        JMenuItem editItem = new JMenuItem("Edit Client", editIcon);
        optionsMenu.add(editItem);
        editItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e){
                Client_view.this.editNewClient();
            }
        });

        ImageIcon deleteIcon = new ImageIcon("Delete Client.png");
        JMenuItem deleteItem = new JMenuItem("Delete Client", deleteIcon);
        optionsMenu.add(deleteItem);
        deleteItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e){
                Client_view.this.deleteNewClient();
            }
        });

        ImageIcon viewIcon = new ImageIcon("View Client.png");
        JMenuItem viewItem = new JMenuItem("View Client", viewIcon);
        optionsMenu.add(viewItem);
        viewItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e){
                viewNewClient();
            }
        });

        ImageIcon placeIcon = new ImageIcon("Place Order.png");
        JMenuItem placeItem = new JMenuItem("Place Order", placeIcon);
        optionsMenu.add(placeItem);
        placeItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e){
                Client_view.this.orderNewClient();
            }
        });
        this.setLayout(null);
        this.setTitle("Client Operations");
        this.setSize(896, 504);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        this.setVisible(true);
    }

    public void addNewClient() {
        final JFrame addNewClient = new JFrame("Add client");

        addNewClient.setVisible(true);
        addNewClient.setBounds(250, 350, 500, 400);
        addNewClient.setLayout((LayoutManager) null);

        JLabel client_nameJL = new JLabel("Name: ");
        client_nameJL.setBounds(80, 80, 100, 20);
        addNewClient.add(client_nameJL);

        final JTextField client_nameJT = new JTextField();
        client_nameJT.setBounds(180, 80, 100, 20);
        addNewClient.add(client_nameJT);

        JLabel client_ageJL = new JLabel("Age: ");
        client_ageJL.setBounds(80, 100, 100, 20);
        addNewClient.add(client_ageJL);

        final JTextField client_ageJT = new JTextField();
        client_ageJT.setBounds(180, 100, 100, 20);
        addNewClient.add(client_ageJT);

        JButton addTheClient = new JButton("Add");
        addTheClient.setBounds(180, 130, 100, 20);
        addTheClient.addActionListener(e -> {
            Client toAdd = new Client(client_nameJT.getText(), Integer.parseInt(client_ageJT.getText()));
            ClientDAO.insert(toAdd);
            addNewClient.setVisible(false);
        });
        addNewClient.add(addTheClient);
    }
    public void editNewClient() {
        final JFrame editNewClient = new JFrame("Edit client");
        editNewClient.setVisible(true);
        editNewClient.setBounds(250, 350, 500, 400);
        editNewClient.setLayout((LayoutManager) null);

        JLabel id_clientJL = new JLabel("Id client: ");
        id_clientJL.setBounds(80, 80, 100, 20);
        editNewClient.add(id_clientJL);

        final JTextField id_clientJT = new JTextField();
        id_clientJT.setBounds(180, 80, 100, 20);
        editNewClient.add(id_clientJT);

        JLabel client_nameJL = new JLabel("Client name: ");
        client_nameJL.setBounds(80, 100, 100, 20);
        editNewClient.add(client_nameJL);

        final JTextField client_nameJT = new JTextField();
        client_nameJT.setBounds(180, 100, 100, 20);
        editNewClient.add(client_nameJT);

        JLabel client_ageJL = new JLabel("Client age: ");
        client_ageJL.setBounds(80, 120, 100, 20);
        editNewClient.add(client_ageJL);

        final JTextField client_ageJT = new JTextField();
        client_ageJT.setBounds(180, 120, 100, 20);
        editNewClient.add(client_ageJT);

        JButton editTheClient = new JButton("Edit");
        editTheClient.setBounds(180, 150, 100, 20);
        editTheClient.addActionListener(e -> {
            ClientDAO.updateByID(client_nameJT.getText(), Integer.parseInt(client_ageJT.getText()), Integer.parseInt(id_clientJT.getText()));
            editNewClient.setVisible(false);
        });
        editNewClient.add(editTheClient);
    }
    /**
     Displays a JFrame for editing a new client, with fields for client ID, name, and age, as well as an "Edit" button to submit changes.
     */
    public void deleteNewClient() {
        final JFrame deleteNewClient = new JFrame("Delete client");
        deleteNewClient.setVisible(true);
        deleteNewClient.setBounds(250, 350, 500, 400);
        deleteNewClient.setLayout((LayoutManager) null);

        JLabel id_clientJL = new JLabel("Id client: ");
        id_clientJL.setBounds(80, 80, 100, 20);
        deleteNewClient.add(id_clientJL);

        final JTextField id_clientJT = new JTextField();
        id_clientJT.setBounds(180, 80, 100, 20);
        deleteNewClient.add(id_clientJT);

        JButton deleteTheClient = new JButton("Delete");
        deleteTheClient.setBounds(180, 110, 100, 20);
        deleteTheClient.addActionListener(e -> {
            ClientDAO.deleteById(Integer.parseInt(id_clientJT.getText()));
            deleteNewClient.setVisible(false);
        });
        deleteNewClient.add(deleteTheClient);
    }
    /**
     Displays a window for ordering a product by a client.
     Allows the user to select a client, a product, and the count of the product to be ordered.
     Upon pressing the "Order" button, the information is saved in the database.

     The window is constructed using Java Swing and consists of:
     a JFrame with the title "Order client"
     two Choice objects to select the client and the product
     a JTextField to input the order count
     a JButton with the text "Order" to confirm the order and save the information in the database
     The window is displayed using the setVisible() method of JFrame.
     */
    public void orderNewClient() {
        final JFrame orderNewClient = new JFrame("Order client");
        orderNewClient.setVisible(true);
        orderNewClient.setBounds(250, 350, 500, 400);
        orderNewClient.setLayout((LayoutManager) null);

        JLabel id_clientJL = new JLabel("Client: ");
        id_clientJL.setBounds(80, 80, 100, 20);
        orderNewClient.add(id_clientJL);

        final Choice id_clientCH = new Choice();
        id_clientCH.setBounds(180, 80, 100, 20);
        orderNewClient.add(id_clientCH);

        JLabel id_productJL = new JLabel("Product: ");
        id_productJL.setBounds(80, 100, 100, 20);
        orderNewClient.add(id_productJL);

        final Choice id_productCH = new Choice();
        id_productCH.setBounds(180, 100, 100, 20);
        orderNewClient.add(id_productCH);

        JLabel product_countJL = new JLabel("Order count: ");
        product_countJL.setBounds(80, 120, 100, 20);
        orderNewClient.add(product_countJL);

        final JTextField product_countJT = new JTextField();
        product_countJT.setBounds(180, 120, 100, 20);
        orderNewClient.add(product_countJT);

        int nrOfClients = ClientDAO.getNrOfClients();
        int j = 1;
        // Populates the Choice object with the available clients
        int nrOfProducts;
        for (nrOfProducts = 1; nrOfProducts <= nrOfClients; ++nrOfProducts) {
            while (ClientDAO.findById(j) == null) {
                ++j;
            }
            if (ClientDAO.findById(j) != null) {
                id_clientCH.add("" + j + "." + ClientDAO.findById(j).getClient_name());
            }
            ++j;
        }
        // Populates the Choice object with the available products
        nrOfProducts = ProductDAO.getNrOfProducts();
        j = 1;
        for (int i = 1; i <= nrOfProducts; ++i) {
            while (ProductDAO.findById(j) == null) {
                ++j;
            }
            if (ProductDAO.findById(j) != null) {
                id_productCH.add("" + j + "." + ProductDAO.findById(j).getProduct_name());
            }
            ++j;
        }
        // Adds an ActionListener to the "Order" button to save the order in the database
        JButton orderTheClient = new JButton("Order");
        orderTheClient.setBounds(180, 150, 100, 20);
        orderTheClient.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                ++Client_view.this.order_number;
                int id_client = Character.getNumericValue(id_clientCH.getSelectedItem().charAt(0));
                int id_product = Character.getNumericValue(id_productCH.getSelectedItem().charAt(0));
                int order_count = Integer.parseInt(product_countJT.getText());
                ClientDAO.order(id_client, id_product, order_count, Client_view.this.order_number);
                orderNewClient.setVisible(false);
            }
        });
        orderNewClient.add(orderTheClient);
    }
    /**
     Opens a new frame to view all the existing clients in the database.
     */
    public void viewNewClient() {
        final JFrame viewNewClient = new JFrame("View clients");
        viewNewClient.setVisible(true);
        viewNewClient.setBounds(250, 350, 500, 400);
        viewNewClient.setLayout(null);

        // Get the number of clients in the database and create an array to store them
        int nrOfClients = ClientDAO.getNrOfClients();
        Object[] clients = new Object[nrOfClients + 1];
        int j = 1;
        for (int i = 1; i <= nrOfClients; i++) {
            // Find the next existing client in the database
            while (ClientDAO.findById(j) == null) {
                j++;
            }
            if (ClientDAO.findById(j) != null) {
                // Add the client to the array if it exists
                clients[i] = ClientDAO.findById(j);
            }
            j++;
        }
        AbstractDAO.viewAllObjects(clients, viewNewClient, nrOfClients);
        repaint();
    }
}
