/**
 The Order_Window class represents the graphical user interface for the order management system.
 */
package Presentation;
import Data_Access.AbstractDAO;
import Data_Access.OrderDAO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
public class Order_view extends JFrame {
    /**
     * The order number of the current order.
     */
    private int orderNumber = 0;
    private JPanel ordersPanel;
    private JPanel buttonPanel;
    private JButton viewOrdersButton;
    /**
     * Creates a new Order_Window object and sets up the graphical user interface.
     */
    public Order_view() {
        this.setLayout(null);
        this.setTitle("Order");
        this.setLocationRelativeTo(null);
        this.setVisible(true);
        this.setBounds(200, 300, 500, 400);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JButton viewOrders = new JButton("orders table");
        viewOrders.setBounds(100, 50, 200, 50);
        viewOrders.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                viewNewOrder();
            }
        });
        add(viewOrders);
    }
    /**
     * Creates a new frame to display a list of all orders in the system.
     */
    public void viewNewOrder() {
        final JFrame viewNewOrder = new JFrame("View Orders");
        viewNewOrder.setVisible(true);
        viewNewOrder.setBounds(200, 300, 500, 400);
        viewNewOrder.setLayout(null);

        int nrOfOrders = OrderDAO.getNrOfOrders();
        Object[] order = new Object[nrOfOrders + 1];
        int j = 1;
        for (int i = 0; i < nrOfOrders; i++) {
            while (OrderDAO.findById(j) == null) {
                j++;
            }
            if (OrderDAO.findById(j) != null) {
                order[j] = OrderDAO.findById(j);
            }
            j++;
        }
        AbstractDAO.viewAllObjects(order, viewNewOrder, nrOfOrders);
        repaint();
    }
}
