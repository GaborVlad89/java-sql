package Data_Access;
import java.io.File;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import static javax.swing.JOptionPane.showMessageDialog;
import ConnectionFactory.ConnectionFactory;
import Model.Client;
/**
 * The ClientDAO class provides methods for accessing and manipulating data in the client table.
 */
public class ClientDAO {
    /** A logger object to log messages. */
    protected static final Logger LOGGER = Logger.getLogger(ClientDAO.class.getName());
    /** The SQL statement to insert a new client into the database. */
    private static final String insertStatementString = "INSERT INTO client (client_name, client_age) VALUES (?,?)";
    /** The SQL statement to retrieve a client with a specified ID from the database. */
    private final static String findStatementString = "SELECT * FROM client where id_client = ?";
    /** The SQL statement to delete a client with a specified ID from the database. */
    private final static String deleteStatementString = "DELETE FROM client where id_client = ?";
    /** The SQL statement to update a client with a specified ID in the database. */
    private final static String updateStatementString = "UPDATE client SET client_name = ?, client_age = ? where id_client = ?";
    /** The SQL statement to count the number of clients in the database. */
    private final static String countStatementString = "SELECT COUNT(id_client) AS rowcount FROM client";
    /**
     * Finds a client with a specified ID in the database.
     *
     * @param id_client the ID of the client to find
     * @return a Client object if the client is found, null otherwise
     */
    public static Client findById(int id_client) {
        Client toReturn = null;

        Connection dbConnection = ConnectionFactory.getConnection();
        PreparedStatement findStatement = null;
        ResultSet rs = null;
        try {
            findStatement = dbConnection.prepareStatement(findStatementString);
            findStatement.setLong(1, id_client);
            rs = findStatement.executeQuery();
            rs.next();

            String client_name = rs.getString("client_name");
            int client_age = rs.getInt("client_age");
            toReturn = new Client(id_client, client_name, client_age);
        } catch (SQLException e) {
            LOGGER.log(Level.WARNING,"ClientDAO:findById " + e.getMessage());
        } finally {
            ConnectionFactory.close(rs);
            ConnectionFactory.close(findStatement);
            ConnectionFactory.close(dbConnection);
        }
        return toReturn;
    }
    /**
     * Deletes a client with a specified ID from the database.
     * @param id_client the ID of the client to delete
     */
    public static void deleteById(int id_client) {
        Connection dbConnection = ConnectionFactory.getConnection();
        PreparedStatement deleteStatement = null;
        PreparedStatement alterStatement = null;
        try {
            deleteStatement = dbConnection.prepareStatement(deleteStatementString);
            deleteStatement.setLong(1, id_client);
            deleteStatement.executeUpdate();
            showMessageDialog(null, "client delete !");

        } catch (SQLException e) {
            LOGGER.log(Level.WARNING,"ClientDAO:deleteById " + e.getMessage());
        } finally {
            ConnectionFactory.close(deleteStatement);
            ConnectionFactory.close(dbConnection);
        }
    }
    /**
     * Updates a client by ID
     * @param client_name the new name of the client
     * @param client_age the new age of the client
     * @param id_client the ID of the client to be updated
     */
    public static void updateByID(String client_name, int client_age, int id_client) {
        Connection dbConnection = ConnectionFactory.getConnection();
        PreparedStatement updateStatement = null;
        try {
            updateStatement = dbConnection.prepareStatement(updateStatementString);
            updateStatement.setLong(3, id_client);
            if (client_name.length() > 0) updateStatement.setString(1, client_name);
            else updateStatement.setString(1, findById(id_client).getClient_name());
            if (client_age != -1) updateStatement.setLong(2, client_age);
            else updateStatement.setLong(2, findById(id_client).getClient_age());
            updateStatement.executeUpdate();
            showMessageDialog(null, "client updated !");
        } catch (SQLException e) {
            LOGGER.log(Level.WARNING,"ClientDAO:updateById " + e.getMessage());
        } finally {
            ConnectionFactory.close(updateStatement);
            ConnectionFactory.close(dbConnection);
        }
    }
    /**
     Inserts a new client into the database.
     @param client the client object to be inserted
     @return the ID of the newly inserted client, or -1 if the insertion failed
     */
    public static int insert(Client client) {
        Connection dbConnection = ConnectionFactory.getConnection();

        PreparedStatement insertStatement = null;
        int insertedId = -1;
        try {
            insertStatement = dbConnection.prepareStatement(insertStatementString, Statement.RETURN_GENERATED_KEYS);
            insertStatement.setString(1, client.getClient_name());
            insertStatement.setInt(2, client.getClient_age());
            insertStatement.executeUpdate();
            showMessageDialog(null, "Client added !");
            ResultSet rs = insertStatement.getGeneratedKeys();
            if (rs.next()) {
                insertedId = rs.getInt(1);
            }
            ConnectionFactory.close(rs);
        } catch (SQLException e) {
            LOGGER.log(Level.WARNING, "ClientDAO:insert " + e.getMessage());
        } finally {
            ConnectionFactory.close(insertStatement);
            ConnectionFactory.close(dbConnection);
        }
        return insertedId;
    }
    /**
     Returns the number of clients in the database.
     @return the number of clients in the database, or -1 if the count query failed
     */
    public static int getNrOfClients() {
        Connection dbConnection = ConnectionFactory.getConnection();
        PreparedStatement countStatement = null;
        int countNumber = -1;
        try {
            countStatement = dbConnection.prepareStatement(countStatementString, Statement.RETURN_GENERATED_KEYS);
            ResultSet rs = countStatement.executeQuery();
            if (rs.next()) {
                countNumber = rs.getInt("rowcount");
            }
            ConnectionFactory.close(rs);
        } catch (SQLException e) {
            LOGGER.log(Level.WARNING, "ClientDAO:getNrOfClients " + e.getMessage());
        } finally {
            ConnectionFactory.close(countStatement);
            ConnectionFactory.close(dbConnection);
        }
        return countNumber;
    }
    /**
     Places an order for a product on behalf of a client.
     @param id_client the ID of the client placing the order
     @param id_product the ID of the product being ordered
     @param order_count the quantity of the product being ordered
     @param order_number the number of the order being placed
     */
    public static void order(int id_client, int id_product, int order_count, int order_number) {
        if (ProductDAO.findById(id_product).getProduct_count() < order_count)
            showMessageDialog(null, "Understock !");
        else {
            if(ProductDAO.decrementStock(id_product, order_count) == 1) {
                int order_price = ProductDAO.findById(id_product).getProduct_price() * order_count;
                try {
                    File file = new File (System.getProperty("user.dir") + "/Order" + order_number + ".txt");
                    PrintWriter writer = new PrintWriter(file);
                    writer.println("Ordered by: " + findById(id_client).getClient_name());
                    writer.println("Product ordered: " + ProductDAO.findById(id_product).getProduct_name());
                    writer.println("Quantity ordered: " + order_count);
                    writer.println("Order price: " + order_price);
                    writer.close();
                    showMessageDialog(null, "Order added in table !");
                    OrderDAO.addOrder(id_client, id_product, order_price);
                }
                catch (Exception e) {
                    System.out.println(e);
                }
            }
        }
    }
}