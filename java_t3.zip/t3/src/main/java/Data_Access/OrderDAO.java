/**
 Provides data access operations for the Order class using a database connection.
 */
package Data_Access;
import ConnectionFactory.ConnectionFactory;
import Model.Order;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
public class OrderDAO {
    protected static final Logger LOGGER = Logger.getLogger(OrderDAO.class.getName());
    /**
     * SQL string to insert an order into the orders table.
     */
    private final static String insertStatementString = "INSERT INTO orders (order_client, order_product, order_price)"
            + " VALUES (?,?,?)";
    /**
     * SQL string to retrieve an order by its ID from the orders table.
     */
    private final static String findStatementString = "SELECT * FROM orders where id_order = ?";
    /**
     * SQL string to count the number of orders in the orders table.
     */
    private final static String countStatementString = "SELECT COUNT(id_order) AS rowcount FROM orders";
    /**
     * Inserts a new order into the orders table.
     *
     * @param id_client   the ID of the client who placed the order
     * @param id_product  the ID of the product that was ordered
     * @param order_price the total price of the order
     */
    public static void addOrder(int id_client, int id_product, int order_price) {
        Connection dbConnection = ConnectionFactory.getConnection();

        PreparedStatement insertStatement = null;
        try {
            insertStatement = dbConnection.prepareStatement(insertStatementString);
            insertStatement.setString(1, ClientDAO.findById(id_client).getClient_name());
            insertStatement.setString(2, ProductDAO.findById(id_product).getProduct_name());
            insertStatement.setInt(3, order_price);
            insertStatement.executeUpdate();
        } catch (SQLException e) {
            LOGGER.log(Level.WARNING, "orderDAO:addOrder " + e.getMessage());
        } finally {
            ConnectionFactory.close(insertStatement);
            ConnectionFactory.close(dbConnection);
        }
    }
    /**
     * Retrieves an order from the orders table by its ID.
     *
     * @param id_order the ID of the order to retrieve
     * @return the Order object that represents the retrieved order, or null if no order was found with the given ID
     */
    public static Order findById(int id_order) {
        Order toReturn = null;
        Connection dbConnection = ConnectionFactory.getConnection();
        PreparedStatement findStatement = null;
        ResultSet rs = null;
        try {
            findStatement = dbConnection.prepareStatement(findStatementString);
            findStatement.setLong(1, id_order);
            rs = findStatement.executeQuery();
            rs.next();
            String order_client = rs.getString("order_client");
            String order_product = rs.getString("order_product");
            //int order_count = rs.getInt("order_count");
            //int order_price = rs.getInt("order_price");
            toReturn = new Order(id_order, order_client, order_product);
        } catch (SQLException e) {
            LOGGER.log(Level.WARNING, "OrderDAO:findById " + e.getMessage());
        } finally {
            ConnectionFactory.close(rs);
            ConnectionFactory.close(findStatement);
            ConnectionFactory.close(dbConnection);
        }
        return toReturn;
    }
    /**
     This method retrieves the total number of orders stored in the database.
     @return an integer representing the total number of orders stored in the database
     */
    public static int getNrOfOrders() {
        Connection dbConnection = ConnectionFactory.getConnection();
        PreparedStatement countStatement = null;
        int countNumber = -1;
        try {
            countStatement = dbConnection.prepareStatement(countStatementString, Statement.RETURN_GENERATED_KEYS);
            ResultSet rs = countStatement.executeQuery();
            if (rs.next()) {
                countNumber = rs.getInt("rowcount");
            }
            ConnectionFactory.close(rs);
        } catch (SQLException e) {
            LOGGER.log(Level.WARNING, "OrderDAO:getNrOfOrders " + e.getMessage());
        } finally {
            ConnectionFactory.close(countStatement);
            ConnectionFactory.close(dbConnection);
        }
        return countNumber;
    }
}