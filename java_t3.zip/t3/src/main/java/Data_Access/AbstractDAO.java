/**
 A generic data access object providing CRUD operations for a specific type T.
 @param <T> the type of the objects that the DAO will operate on

 **/
package Data_Access;
import java.beans.IntrospectionException;
import java.beans.PropertyDescriptor;
import java.lang.reflect.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;
import javax.swing.*;
public class AbstractDAO<T> {
    /**
     * A logger for the class.
     */
    protected static final Logger LOGGER = Logger.getLogger(AbstractDAO.class.getName());
    /**
     * The type of the class that the DAO will operate on.
     */
    private final Class<T> type;
    /**
     * Constructs a new instance of the DAO with the type parameterized.
     */
    public AbstractDAO() {
        this.type = (Class<T>) ((ParameterizedType) getClass().getGenericSuperclass()).getActualTypeArguments()[0];
    }
    /**
     * Displays all objects of a certain type in a JTable.
     * @param objects an array of objects of the specified type
     * @param viewObjectsJF the JFrame where the JTable will be displayed
     * @param nrOfRows the number of rows to be displayed in the JTable
     */
    public static void viewAllObjects(Object[] objects, JFrame viewObjectsJF, int nrOfRows) {
        String[][] rowData;
        String[] columnNames;
        int columnNumber = 0;
        Object auxObject = objects[1];
        for (Field field : auxObject.getClass().getDeclaredFields()) {
            columnNumber++;
        }
        columnNames = new String[columnNumber];
        rowData = new String[nrOfRows][columnNumber];

        int index = 0;
        for (Field field : auxObject.getClass().getDeclaredFields()) {
            field.setAccessible(true);
            columnNames[index] = field.getName();
            index++;
        }
        for (int i = 1; i <= nrOfRows; i++) {
            int j = 0;
            for (Field field : objects[i].getClass().getDeclaredFields()) {
                j++;
                field.setAccessible(true);
                Object value;
                try {
                    value = field.get(objects[i]);
                    rowData[i - 1][j - 1] = value.toString();
                } catch (IllegalArgumentException e) {
                    System.out.println(e);
                } catch (IllegalAccessException e) {
                    System.out.println(e);
                }
            }
        }
        JTable allObjectsJT = new JTable(rowData, columnNames);
        allObjectsJT.setBounds(40, 40, 400, 280);
        JScrollPane jScrollPane = new JScrollPane();
        jScrollPane.setBounds(40, 40, 400, 280);
        jScrollPane.getViewport().add(allObjectsJT, null);
        viewObjectsJF.add(jScrollPane);
    }
    /**
     * Creates a SELECT SQL query for a specific field of the class.
     * @param field the name of the field to be used in the query
     * @return the generated SELECT query as a String
     */
    private String createSelectQuery(String field) {
        StringBuilder sb = new StringBuilder();
        sb.append("SELECT ");
        sb.append(" * ");
        sb.append(" FROM ");
        sb.append(type.getSimpleName());
        sb.append(" WHERE " + field + " =?");
        return sb.toString();
    }
    /**
     * Returns all objects of the specified type from the database.
     * @return a list of all objects of the specified type
     */
    private List<T> createObjects(ResultSet resultSet) {
        List<T> list = new ArrayList<T>();
        Constructor[] ctors = type.getDeclaredConstructors();
        Constructor ctor = null;
        for (int i = 0; i < ctors.length; i++) {
            ctor = ctors[i];
            if (ctor.getGenericParameterTypes().length == 0)
                break;
        }
        try {
            while (resultSet.next()) {
                ctor.setAccessible(true);
                T instance = (T)ctor.newInstance();
                for (Field field : type.getDeclaredFields()) {
                    String fieldName = field.getName();
                    Object value = resultSet.getObject(fieldName);
                    PropertyDescriptor propertyDescriptor = new PropertyDescriptor(fieldName, type);
                    Method method = propertyDescriptor.getWriteMethod();
                    method.invoke(instance, value);
                }
                list.add(instance);
            }
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (SecurityException e) {
            e.printStackTrace();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (IntrospectionException e) {
            e.printStackTrace();
        }
        return list;
    }
    public T insert(T t) {
        // TODO:
        return t;
    }
    public T update(T t) {
        // TODO:
        return t;
    }
}

